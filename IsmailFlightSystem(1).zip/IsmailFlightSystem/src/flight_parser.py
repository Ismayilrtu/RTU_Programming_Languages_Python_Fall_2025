import argparse
import json
import os
import sys
import re
from datetime import datetime

DATE_FORMAT = "%Y-%m-%d %H:%M"

# Check if line is empty
def is_empty(line: str) -> bool:
    return line.strip() == ""

# Check if line is a comment (starts with #)
def is_comment(line: str) -> bool:
    return line.strip().startswith("#")

# Validate flight data
def validate_flight_data(fields):
    errors = []
    
    # Ensure there are 6 fields
    if len(fields) != 6:
        errors.append("Incorrect number of fields.")
        return None, errors

    flight_code, origin_city, destination_city, dep_time_str, arr_time_str, flight_price_str = [f.strip() for f in fields]

    # Validate flight_code (3 to 6 alphanumeric characters)
    if not re.match(r"[A-Za-z0-9]{3,6}", flight_code):
        errors.append("Invalid flight_code.")
    
    # Validate origin_city and destination_city (3 uppercase letters)
    if not re.match(r"[A-Z]{3}", origin_city) or not re.match(r"[A-Z]{3}", destination_city):
        errors.append("Invalid origin or destination city code.")

    # Validate datetime format and check arrival time is after departure time
    try:
        dep_time = datetime.strptime(dep_time_str, DATE_FORMAT)
        arr_time = datetime.strptime(arr_time_str, DATE_FORMAT)
        if arr_time <= dep_time:
            errors.append("Arrival before departure.")
    except ValueError:
        errors.append("Invalid datetime format.")

    # Validate price (positive number)
    try:
        price = float(flight_price_str)
        if price <= 0:
            errors.append("Invalid price.")
    except ValueError:
        errors.append("Invalid price format.")
    
    # If errors exist, return None and error messages
    if errors:
        return None, errors

    # Return flight data as a dictionary if no errors
    return {
        "flight_code": flight_code,
        "origin_city": origin_city,
        "destination_city": destination_city,
        "departure_time": dep_time_str,
        "arrival_time": arr_time_str,
        "flight_price": price
    }, []

# Parse CSV files to extract flight data
def parse_flight_schedule(path, valid_flights, errors):
    try:
        with open(path, "r", encoding="utf-8") as file:
            line_number = 0
            for line in file:
                line_number += 1
                line = line.rstrip("\n")

                # Skip empty lines and comment lines
                if is_empty(line) or is_comment(line):
                    continue

                # Split the line into fields and validate
                parts = line.split(",")
                flight, errs = validate_flight_data(parts)

                # If there are errors, add them to the error list
                if errs:
                    errors.append(f"Line {line_number}: {line} → {'; '.join(errs)}")
                else:
                    valid_flights.append(flight)

    except FileNotFoundError:
        print(f"Error: File '{path}' not found.", file=sys.stderr)
        sys.exit(1)

# Save data to a JSON file
def save_json(path, data):
    output_dir = os.path.dirname(path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)  # Create the directory if it doesn't exist
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# Save data to a text file (for errors)
def save_txt(path, data):
    output_dir = os.path.dirname(path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)  # Create the directory if it doesn't exist
    with open(path, "w", encoding="utf-8") as f:
        for line in data:
            f.write(line + "\n")

# Load JSON data from a file
def load_json(path):
    """Load JSON data from a file"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: File '{path}' not found.", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: Failed to decode JSON from file '{path}'", file=sys.stderr)
        sys.exit(1)

# Execute queries on the loaded JSON database
def execute_queries(database, query_json_path):
    """Execute queries on the loaded JSON database"""
    try:
        with open(query_json_path, "r", encoding="utf-8") as f:
            queries = json.load(f)
    except FileNotFoundError:
        print(f"Error: Query file '{query_json_path}' not found.", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError:
        print(f"Error: Failed to decode query JSON file.", file=sys.stderr)
        sys.exit(1)

    response_array = []

    # Process each query
    for query in queries:
        matches = []
        for flight in database:
            if all(flight.get(key) == value for key, value in query.items()):
                matches.append(flight)

        response_array.append({
            "query": query,
            "matches": matches
        })

    # Save query results to a response JSON file
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    filename = f"response_{timestamp}.json"
    save_json(filename, response_array)
    print(f"Query results saved to: {filename}")

# Main function to parse the CSV files and save the results
def main():
    parser = argparse.ArgumentParser(description="Flight data parser and query tool.")
    
    # Arguments for directory, output JSON, and query file
    parser.add_argument("-d", "--directory", help="Directory containing flight schedule CSV files.")
    parser.add_argument("-o", "--output", help="Output path for valid flights JSON.")
    parser.add_argument("-q", "--query", help="Query file for executing queries.")
    parser.add_argument("-j", "--json-db", help="Load an existing JSON database for queries.")
    
    args = parser.parse_args()

    valid_flights = []  # List to hold valid flight data
    errors = []  # List to hold errors encountered during parsing

    # If directory argument is provided, parse CSV files
    if args.directory:
        for file_name in os.listdir(args.directory):
            if file_name.endswith(".csv"):
                parse_flight_schedule(os.path.join(args.directory, file_name), valid_flights, errors)

        save_json(args.output or "flight_database.json", valid_flights)
        save_txt("flight_errors.txt", errors)

    # If a JSON database is provided, load it and execute queries
    if args.json_db:
        database = load_json(args.json_db)
        if args.query:
            execute_queries(database, args.query)

# Run the main function
if __name__ == "__main__":
    main()
